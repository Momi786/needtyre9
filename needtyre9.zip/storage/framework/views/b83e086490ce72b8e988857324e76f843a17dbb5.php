<?php $__env->startSection('content'); ?>

    <!-- main-area -->
    <main class="mt-70">

        <!-- breadcrumb-area -->
        <section class="breadcrumb-area breadcrumb-bg inventory-details-breadcrumb" data-background="<?php echo e(url('web-img/bg/breadcrumb_bg.jpg')); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-content text-center">
                            <h2><?php echo e($item->item); ?></h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/products')); ?>">All Products</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($item->item); ?></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->


        <!-- inventory-list-area -->
        <section class="inventory-details-area gray-lite-bg pt-70 pb-120">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="inventory-details-description mb-30">
                            <div class="inv-details-title">
                                <h5><?php echo e($item->item); ?></h5>
                            </div>
                            <div class="inv-details-img">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <img src="<?php echo e(url('web-img/images/inv_details_img01.jpg')); ?>" alt="">
                                        <div class="inventory-list-content">
                                            <div class="inv-content-top">
                                                <ul class="ul">
                                                    <li class="option1 option mb-3">
                                                        <?php if($item->qty < 5): ?>
                                                            <a href="" class="new"> <i class="fa fa-times"></i> Less Than 5 in Stock </a>
                                                        <?php else: ?>
                                                            <a href="#">InStock <?php echo e($item->qty); ?></a>
                                                        <?php endif; ?>
                                                    </li>
                                                    <li><i class="fas fa-shipping-fast"></i> Free Shipping</li>
                                                    <li><i class="fas fa-handshake"></i> Risk-Free Guarantee</li>
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="inventory-list-content">
                                            <h1><a href="#"><?php echo e($item->brand); ?></a></h1>
                                            <h4><a href="<?php echo e(url('/detail-products')); ?>/<?php echo e($item->id); ?>"><?php echo e($item->item); ?></a></h4>
                                            <p class="location"><i class="fas fa-map-marker-alt"></i><?php echo e($item->LongDescription); ?></p>
                                            <div class="inv-item-meta">
                                                <ul class="justify-content-end">
                                                    <li class="call"><a href="#"><i class="fas fa-shopping-cart"></i>Add To Cart</a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="inventory-features mb-30">
                            <div class="inv-details-title">
                                <h5 class="text-center">Overview</h5>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="inventory-features-item">
                                        <h6>Tire Overview</h6>
                                        <span><?php echo e($item->LongDescription); ?></span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>Manufacturer Part Number:</h6>
                                        <span><?php echo e($item->item); ?></span>
                                    </div>
                                </div>
                            </div>

                        </div>
                        
                        <div class="inventory-features mb-30">
                            <div class="inv-details-title">
                                <h5 class="text-center">TIRE SPECIFICATION</h5>
                            </div>
                            <div class="row">
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>Section WidthIn :</h6>
                                        <span>Coupe</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>Aspect Ratio :</h6>
                                        <span>BMW</span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>Rim Size :</h6>
                                        <span>Automatic</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>SpeedRate :</h6>
                                        <span>2020</span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>40hc :</h6>
                                        <span>New</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>LoadIndex :</h6>
                                        <span>Petrol</span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>MaxLoad :</h6>
                                        <span>Front Wheel Drive</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>MaxPressure :</h6>
                                        <span>5-door</span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>OveralDiameter :</h6>
                                        <span>Front Wheel Drive</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>TreadDepth :</h6>
                                        <span>5-door</span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>UTQG :</h6>
                                        <span>Front Wheel Drive</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>MinRimWidth :</h6>
                                        <span>5-door</span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>Measured Rim Width :</h6>
                                        <span>Front Wheel Drive</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>Max Rim Width :</h6>
                                        <span>5-door</span>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="inventory-features-item">
                                        <h6>DOT Registration :</h6>
                                        <span>Front Wheel Drive</span>
                                    </div>
                                    <div class="inventory-features-item">
                                        <h6>Manufacturer :</h6>
                                        <span>5-door</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="inventory-features mb-30">
                            <div class="inv-details-title">
                                <h5 class="text-center">TREAD LIFE WARRANTY</h5>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="inventory-features-item">
                                        <h6>Tire Overview</h6>
                                        <span><?php echo e($item->LongDescription); ?></span>
                                    </div>
                                    <div class="inventory-features-item">
                                        
                                        <span>This product is not covered by a manufacturer’s treadlife warranty.</span>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- inventory-list-area-end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\needtyre9\resources\views/web/ptoducts/search.blade.php ENDPATH**/ ?>