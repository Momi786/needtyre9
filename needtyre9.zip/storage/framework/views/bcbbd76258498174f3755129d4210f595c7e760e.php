<?php $__env->startSection('content'); ?>

    <!-- main-area -->
    <main class="mt-70">

        <!-- breadcrumb-area -->
        <section class="breadcrumb-area breadcrumb-bg" data-background="img/bg/breadcrumb_bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-content text-center">
                            <h2>All Type Of Tires</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">All Type Of Tires</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- breadcrumb-area-end -->

        <!-- inventory-list-area -->
        <section class="inventory-list-area gray-lite-bg pt-120 pb-120">
            <div class="container">
                <div class="inventory-meta-wrap mb-50">
                    <div class="row align-items-center">
                        <div class="col-xl-8 col-lg-7 col-md-6">
                            <div class="inventory-top-meta">
                                <ul>
                                    <li class="find">Total Tires Find : <span><?php echo e($count); ?></span></li>




                                </ul>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <form action="#" class="inventory-short-meta">
                                <label>Sort by :</label>
                                <select name="name" class="selected">
                                    <option value="">New Listed : Newest</option>
                                    <option value="">Old Listed : Oldest</option>
                                    <option value="">Price High to Low</option>
                                    <option value="">Price Low to High</option>
                                    <option value="">Most Popular</option>
                                </select>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-xl-8 col-lg-7 col-md-9">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="inventory-list-item">
                                <div class="inventory-list-thumb">
                                    <img src="<?php echo e(url('web-img/images/inventory_list_img01.jpg')); ?>" alt="">
                                    <ul class="inv-thumb-meta">
                                        <li><a href="<?php echo e(url('web-img/images/inventory_list_img01.jpg')); ?>" class="popup-image" data-toggle="tooltip" data-placement="top" data-original-title="View Image"><i class="fas fa-camera"></i></a></li>
                                        <li><a href="#" data-toggle="tooltip" data-placement="top" data-original-title="Add to Favorite"><i class="fas fa-star"></i></a></li>
                                        <li><a href="inventory-details.html" data-toggle="tooltip" data-placement="top" data-original-title="Details"><i class="fas fa-plus"></i></a></li>
                                    </ul>
                                </div>
                                <div class="inventory-list-content">
                                    <div class="inv-content-top">
                                        <ul>
                                            <li class="option">
                                                    <?php if($item->qty < 5): ?>
                                                        <a href="" class="new"> Less Than 5 in Stock </a>
                                                    <?php else: ?>
                                                        <a href="#">InStock <?php echo e($item->qty); ?></a>
                                                    <?php endif; ?>
                                            </li>

                                        </ul>
                                    </div>
                                    <h6><a href="#"><?php echo e($item->brand); ?></a></h6>
                                    <h4><a href="<?php echo e(url('/detail-products')); ?>/<?php echo e($item->id); ?>"><?php echo e($item->item); ?></a></h4>
                                    <p class="location"><i class="fas fa-map-marker-alt"></i><?php echo e($item->LongDescription); ?></p>
                                    <div class="inv-item-meta">
                                        <ul>
                                            <li class="call"><a href="#"><i class="fas fa-shipping-fast"></i>Free Shipping</a></li>
                                            <li><i class="fas fa-handshake"></i> Risk-Free Guarantee</li>
                                            <li>Doors : 2</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-right">
                            <?php echo e($items->links()); ?>

                        </div>
                    </div>
























































































































                </div>
            </div>
        </section>
        <!-- inventory-list-area-end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\needtyre9\resources\views/web/ptoducts/index.blade.php ENDPATH**/ ?>